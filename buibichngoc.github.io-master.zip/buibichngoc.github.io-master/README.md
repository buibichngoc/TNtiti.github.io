# https://buibichngoc.github.io
- thiết kế phần mềm theo yêu cầu(Software design on demand)
- thiết kế website theo yêu cầu combo SEO website(design webon demand combo SEO website)
- IT Support
- Teamviewer dạy học hack, photoshop, code(java, c++, javascript, html, css)/ teaching hack, Photoshop, code(java, c++, javascript, html, css)
- Contact: https://www.facebook.com/buibichngocth
